#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define REAL_WIDTH(i) ( ( i + 31 ) / 32 * 4 )

// --#pragma pack(1)-- //

/*Some pre-definitions of the data types and structure*/
typedef unsigned short WORD;
typedef unsigned int DWORD;
typedef unsigned char BYTE;

/*image file header*/
typedef struct tagBITMAPFILEHEADER{
    //WORD bfType;            这个地方有点问题的，感觉不是14字节。。。。所以单独读取
    DWORD bfSize;
    WORD bfReserved1;
    WORD bfReserved2;
    DWORD bfOffBits;
}BITMAPFILEHEADER;

/*image information header*/
typedef struct tagBITMAPINFOHEADER{
    DWORD biSize;
    DWORD biWidth; //注意：此处的biWidth不是实际的图像宽度，而是理论上每行的像素个数
    DWORD biHeight;
    WORD biPlanes;
    WORD biBitCount;
    DWORD biCompression;
    DWORD biSizeImage;
    DWORD biXPelsPerMeter;
    DWORD biYPelsPerMeter;
    DWORD biClrUsed;
    DWORD biClrImportant;
}BITMAPINFOHEADER;

/* the palette */
typedef struct tagRGBQUAD{
    BYTE rgbBlue;    
    BYTE rgbGreen;   
    BYTE rgbRed;      
    BYTE rgbReserved;
}RGBQUAD;

long real_width = 0; //记录每一行实际的字节数

void Readimage( FILE *fp, BITMAPFILEHEADER *fileHeader, BITMAPINFOHEADER *infoHeader, RGBQUAD *pallete );
BYTE THRESHOLD( BYTE **table, int j, DWORD height, DWORD width ); //求出给定矩阵内的全局最佳阈值
double Otsu( BYTE **table, int j, BYTE tempThreshold, DWORD height, DWORD width ); //在给定矩阵中用大津算法求出当前阈值的类间方差
void Writeimage( FILE *fp, BITMAPFILEHEADER fileHeader, BITMAPINFOHEADER infoHeader, RGBQUAD Pallete[], BYTE **pixeldata ); //将bmp需要的数据写入文件
void Binarization( BYTE **pixeldata, BITMAPINFOHEADER infoHeader );
void Erosion( BYTE **pixeldata, BYTE **pixeldataNew, BITMAPINFOHEADER infoHeader );
void Dilation( BYTE **pixeldata, BYTE **pixeldataNew, BITMAPINFOHEADER infoHeader );

int main( int argc, char *argv[] )
{
    BITMAPFILEHEADER fileHeader;
    BITMAPINFOHEADER infoHeader;
    RGBQUAD pallete[256];
    BYTE **pixeldata = NULL;   
    BYTE **pixeldataNew = NULL; 

    FILE *grayscale;
    FILE *binary_image; //二值化
    FILE *erosion;   //腐蚀
    FILE *dilation;  //膨胀
    FILE *opening;   //开运算
    FILE *closing;   //闭运算

    if( strcmp( argv[1], "binarization") == 0 ){
        grayscale = fopen( argv[2], "rb" );
        if( grayscale == NULL ){
            printf( "The grayscale image doesn't exist!\n" );
            return -1;
        }

        Readimage( grayscale, &fileHeader, &infoHeader, pallete );

        if( infoHeader.biBitCount == 8 ){
            //---初始化存储真彩图所有像素灰度数据的数组，大小是[infoHeader.biHeight][real_width]---//
            pixeldata = (BYTE **)malloc( sizeof(BYTE *) * infoHeader.biHeight );
            for( int i = 0; i < infoHeader.biHeight; i++ ) 
                pixeldata[i] = (BYTE *)calloc( real_width, 1 );

            //从灰度图中读取灰度数据
            for( int i  = 0; i < infoHeader.biHeight; i++ ){
                fread( pixeldata[i], real_width, 1, grayscale );
            }
            fclose( grayscale );

            //用找到的全局最佳阈值对灰度图所有像素进行遍历二值化
            Binarization( pixeldata, infoHeader );
            //将二值化后的数据写入新的图
            binary_image = fopen( argv[3], "wb" );
            Writeimage( binary_image, fileHeader, infoHeader, pallete, pixeldata );
            printf( "OK! The binary image has been created!\n" );
            for( int i = 0; i < infoHeader.biHeight; i++ )
                free( pixeldata[i] );
            free( pixeldata );
            return 0;
        }else{
            printf( "Please use a grayscale image with biBitCount of 8!\n" );
            return -1;
        }
    }else if( strcmp( argv[1], "erosion" ) == 0 ){
        binary_image = fopen( argv[2], "rb" );
        if( binary_image == NULL ){
            printf( "There does not exist a binary image!" );
            return -1;
        }
        Readimage( binary_image, &fileHeader, &infoHeader, pallete );
        //从灰度图中读取灰度数据
        pixeldata = (BYTE **)malloc( sizeof(BYTE *) * infoHeader.biHeight );
        for( int i = 0; i < infoHeader.biHeight; i++ ) 
            pixeldata[i] = (BYTE *)calloc( real_width, 1 ); //为图像数据分配空间
        for( int i  = 0; i < infoHeader.biHeight; i++ ){
            fread( pixeldata[i], real_width, 1, binary_image );
        }
        //构建新的像素点数据
        pixeldataNew = (BYTE **)malloc( sizeof(BYTE *) * infoHeader.biHeight );
        for( int i = 0; i < infoHeader.biHeight; i++ ) 
            pixeldataNew[i] = (BYTE *)calloc( real_width, 1 ); //为图像数据分配空间

        fclose( binary_image );
        Erosion( pixeldata, pixeldataNew, infoHeader );
        erosion = fopen( argv[3], "wb" );
        if( erosion == NULL ){
            printf( "Fail to create the erosion of the binary image!\n" );
            return -1;
        }
        Writeimage( erosion, fileHeader, infoHeader, pallete, pixeldataNew );
        printf( "OK! The erosion image has been created!\n" );
        for( int i = 0; i < infoHeader.biHeight; i++ )
            free( pixeldata[i] );
        free( pixeldata );
        for( int i = 0; i < infoHeader.biHeight; i++ )
            free( pixeldataNew[i] );
        free( pixeldataNew );
        return 0;
    }else if( strcmp( argv[1], "dilation" ) == 0 ){
        binary_image = fopen( argv[2], "rb" );
        if( binary_image == NULL ){
            printf( "There does not exist a binary image!" );
            return -1;
        }
        Readimage( binary_image, &fileHeader, &infoHeader, pallete );
        //从灰度图中读取灰度数据
        pixeldata = (BYTE **)malloc( sizeof(BYTE *) * infoHeader.biHeight );
        for( int i = 0; i < infoHeader.biHeight; i++ ) 
            pixeldata[i] = (BYTE *)calloc( real_width, 1 ); //为图像数据分配空间
        for( int i  = 0; i < infoHeader.biHeight; i++ ){
            fread( pixeldata[i], real_width, 1, binary_image );
        }
        //构建新的像素点数据
        pixeldataNew = (BYTE **)malloc( sizeof(BYTE *) * infoHeader.biHeight );
        for( int i = 0; i < infoHeader.biHeight; i++ ) 
            pixeldataNew[i] = (BYTE *)calloc( real_width, 1 ); //为图像数据分配空间

        fclose( binary_image );
        Dilation( pixeldata, pixeldataNew, infoHeader );
        dilation = fopen( argv[3], "wb" );
        if( dilation == NULL ){
            printf( "Fail to create the dilation of the binary image!\n" );
            return -1;
        }
        Writeimage( dilation, fileHeader, infoHeader, pallete, pixeldataNew );
        printf( "OK! The dilation image has been created!\n" );
        for( int i = 0; i < infoHeader.biHeight; i++ )
            free( pixeldata[i] );
        free( pixeldata );
        for( int i = 0; i < infoHeader.biHeight; i++ )
            free( pixeldataNew[i] );
        free( pixeldataNew );
        return 0;
    }else if( strcmp( argv[1], "opening" ) == 0 ){
        binary_image = fopen( argv[2], "rb" );
        if( binary_image == NULL ){
            printf( "There does not exist a binary image!" );
            return -1;
        }
        Readimage( binary_image, &fileHeader, &infoHeader, pallete );
        //从灰度图中读取灰度数据
        pixeldata = (BYTE **)malloc( sizeof(BYTE *) * infoHeader.biHeight );
        for( int i = 0; i < infoHeader.biHeight; i++ ) 
            pixeldata[i] = (BYTE *)calloc( real_width, 1 ); //为图像数据分配空间
        for( int i  = 0; i < infoHeader.biHeight; i++ ){
            fread( pixeldata[i], real_width, 1, binary_image );
        }
        fclose( binary_image );
        //构建新的像素点数据
        pixeldataNew = (BYTE **)malloc( sizeof(BYTE *) * infoHeader.biHeight );
        for( int i = 0; i < infoHeader.biHeight; i++ ) 
            pixeldataNew[i] = (BYTE *)calloc( real_width, 1 ); //为图像数据分配空间

        Erosion( pixeldata, pixeldataNew, infoHeader );
        for( int i = 0; i < infoHeader.biHeight; i++ )
            for( int j = 0; j < infoHeader.biWidth; j++ )
                pixeldata[i][j] = 0;
        Dilation( pixeldataNew, pixeldata, infoHeader );

        opening = fopen( argv[3], "wb" );
        if( opening == NULL ){
            printf( "Fail to create the opening of the binary image!\n" );
            return -1;
        }
        Writeimage( opening, fileHeader, infoHeader, pallete, pixeldata );
        printf( "OK! The opening image has been created!\n" );
        for( int i = 0; i < infoHeader.biHeight; i++ )
            free( pixeldata[i] );
        free( pixeldata );
        for( int i = 0; i < infoHeader.biHeight; i++ )
            free( pixeldataNew[i] );
        free( pixeldataNew );
        return 0;
    }else if( strcmp( argv[1], "closing" ) == 0 ){
        binary_image = fopen( argv[2], "rb" );
        if( binary_image == NULL ){
            printf( "There does not exist a binary image!" );
            return -1;
        }
        Readimage( binary_image, &fileHeader, &infoHeader, pallete );
        //从灰度图中读取灰度数据
        pixeldata = (BYTE **)malloc( sizeof(BYTE *) * infoHeader.biHeight );
        for( int i = 0; i < infoHeader.biHeight; i++ ) 
            pixeldata[i] = (BYTE *)calloc( real_width, 1 ); //为图像数据分配空间
        for( int i  = 0; i < infoHeader.biHeight; i++ ){
            fread( pixeldata[i], real_width, 1, binary_image );
        }
        fclose( binary_image );
        //构建新的像素点数据
        pixeldataNew = (BYTE **)malloc( sizeof(BYTE *) * infoHeader.biHeight );
        for( int i = 0; i < infoHeader.biHeight; i++ ) 
            pixeldataNew[i] = (BYTE *)calloc( real_width, 1 ); //为图像数据分配空间

        Dilation( pixeldata, pixeldataNew, infoHeader );
        for( int i = 0; i < infoHeader.biHeight; i++ )
            for( int j = 0; j < infoHeader.biWidth; j++ )
                pixeldata[i][j] = 0;
        Erosion( pixeldataNew, pixeldata, infoHeader );

        closing = fopen( argv[3], "wb" );
        if( closing == NULL ){
            printf( "Fail to create the closing of the binary image!\n" );
            return -1;
        }
        Writeimage( closing, fileHeader, infoHeader, pallete, pixeldata );
        printf( "OK! The closing image has been created!\n" );
        for( int i = 0; i < infoHeader.biHeight; i++ )
            free( pixeldata[i] );
        free( pixeldata );
        for( int i = 0; i < infoHeader.biHeight; i++ )
            free( pixeldataNew[i] );
        free( pixeldataNew );
        return 0;
    }

    return 0;
}

void Readimage( FILE *fp, BITMAPFILEHEADER *fileHeader, BITMAPINFOHEADER *infoHeader, RGBQUAD *pallete )
{
    WORD bfType;
    fseek( fp, 0, SEEK_SET );
    fread( &bfType, sizeof(WORD), 1, fp );/* 单独读取 “BM” */
    if( bfType == 0x4d42 ){
        printf("OK! the image is bmp!\n");
        fread( fileHeader, sizeof(BITMAPFILEHEADER), 1, fp );/*read the image file header*/
        fread( infoHeader, sizeof(BITMAPINFOHEADER), 1, fp );/*read the image information header*/
    }else{
        printf("This is not a bmp image!\n");
        exit(0);
    }
    real_width = REAL_WIDTH( infoHeader->biBitCount * infoHeader->biWidth );
    //读取灰度图的调色板数据，8位的灰度图有256个灰度
    fread( pallete, sizeof(RGBQUAD), 256, fp );
}

void Binarization( BYTE **pixeldata, BITMAPINFOHEADER infoHeader )
{
    int i, j;
    BYTE Threshold;  //给定区域的全局最佳阈值
    DWORD block_h, block_w;
    //确定合适大小的block
    for( block_h = infoHeader.biHeight / 6; block_h < infoHeader.biHeight; block_h++ )
        if( infoHeader.biHeight % block_h == 0 ) break;
    for( block_w = real_width / 6; block_w < infoHeader.biWidth; block_w++ )
        if( infoHeader.biWidth % block_w == 0 ) break;
    //以这个block的大小为单元遍历整个图的像素点
    //注意：需要避开每行末尾的垃圾数据，同时在一个block里二值化
    for( i = 0; i < (infoHeader.biHeight / block_h); i++ ){
        for( j = 0; j < (infoHeader.biWidth / block_w); j++ ){
            //在一个block中时， 包括求出阈值和对block中的像素点二值化
            Threshold = THRESHOLD( pixeldata + i * block_h, j, block_h, block_w );
            for( int l = 0; l < block_h; l++ ){
                for( int g = 0; g < block_w; g++ ){
                    if( pixeldata[i*block_h + l][j*block_w + g] > Threshold ) pixeldata[i*block_h + l][j*block_w + g] = 255;
                    else pixeldata[i*block_h + l][j*block_w + g] = 0;
                }
            }
        }
    }
}

void Dilation( BYTE **pixeldata, BYTE **pixeldataNew, BITMAPINFOHEADER infoHeader )
{
    for( int i = 0; i < infoHeader.biHeight; i++ ){
        for( int j = 0; j < infoHeader.biWidth; j++ ){
            if( pixeldata[i][j] == 255 ){
                pixeldataNew[i][j] = 255;
                continue;
            }
            else{
                //四条边线处理
                if( i == 0 ){
                    if( j == 0 )
                        if( pixeldata[i][j + 1] || pixeldata[i + 1][j] ) pixeldataNew[i][j] = 255;
                    else if( j == infoHeader.biWidth - 1 )
                        if( pixeldata[i][j - 1] || pixeldata[i + 1][j] ) pixeldataNew[i][j] = 255;
                    else
                        if( pixeldata[i][j + 1] || pixeldata[i + 1][j] || pixeldata[i][j - 1] ) pixeldataNew[i][j] = 255;
                }else if( i == infoHeader.biHeight - 1 ){
                    if( j == 0 )
                        if( pixeldata[i][j + 1] || pixeldata[i - 1][j] ) pixeldataNew[i][j] = 255;
                    else if( j == infoHeader.biWidth - 1 )
                        if( pixeldata[i][j - 1] || pixeldata[i - 1][j] ) pixeldataNew[i][j] = 255;
                    else
                        if( pixeldata[i][j - 1] || pixeldata[i - 1][j] || pixeldata[i][j + 1] ) pixeldataNew[i][j] = 255;
                }else if( j == 0 ){
                    if( pixeldata[i][j + 1] || pixeldata[i + 1][j] || pixeldata[i - 1][j] ) pixeldataNew[i][j] = 255;
                }else if( j == infoHeader.biWidth - 1 ){
                      if( pixeldata[i - 1][j] || pixeldata[i + 1][j] || pixeldata[i][j - 1] ) pixeldataNew[i][j] = 255;
                }else{ //一般情况
                    if( pixeldata[i - 1][j] || pixeldata[i + 1][j] || pixeldata[i][j - 1] || pixeldata[i][j + 1] ) pixeldataNew[i][j] = 255;
                }
            }
        }
    }
}

void Erosion( BYTE **pixeldata, BYTE **pixeldataNew, BITMAPINFOHEADER infoHeader )
{
    for( int i = 0; i < infoHeader.biHeight; i++ ){
        for( int j = 0; j < infoHeader.biWidth; j++ ){
            if( pixeldata[i][j] ){
                //四条边线处理
                if( i == 0 ){
                    if( j == 0 )
                        if( pixeldata[i][j + 1] && pixeldata[i + 1][j] ) pixeldataNew[i][j] = 255;
                    else if( j == infoHeader.biWidth - 1 )
                          if( pixeldata[i][j - 1] && pixeldata[i + 1][j] ) pixeldataNew[i][j] = 255;
                    else
                        if( pixeldata[i][j + 1] && pixeldata[i + 1][j] && pixeldata[i][j - 1] ) pixeldataNew[i][j] = 255;
                }else if( i == infoHeader.biHeight - 1 ){
                    if( j == 0 )
                        if( pixeldata[i][j + 1] && pixeldata[i - 1][j] ) pixeldataNew[i][j] = 255;
                    else if( j == infoHeader.biWidth - 1 )
                        if( pixeldata[i][j - 1] && pixeldata[i - 1][j] ) pixeldataNew[i][j] = 255;
                    else
                        if( pixeldata[i][j - 1] && pixeldata[i - 1][j] && pixeldata[i][j + 1] ) pixeldataNew[i][j] = 255;
                }else if( j == 0 ){
                    if( pixeldata[i][j + 1] && pixeldata[i + 1][j] && pixeldata[i - 1][j] ) pixeldataNew[i][j] = 255;
                }else if( j == infoHeader.biWidth - 1 ){
                      if( pixeldata[i - 1][j] && pixeldata[i + 1][j] && pixeldata[i][j - 1] ) pixeldataNew[i][j] = 255;
                }else{ //一般情况
                    if( pixeldata[i - 1][j] && pixeldata[i + 1][j] && pixeldata[i][j - 1] && pixeldata[i][j + 1] ) pixeldataNew[i][j] = 255;
                }
            }
        }
    }
}

BYTE THRESHOLD( BYTE **table, int j, DWORD height, DWORD width )
{
    DWORD k = 0; //---不能用BYTE类型，因为超过255会回到0---//
    double maxMU, tempMU; //最大类间方差
    BYTE minimal = table[0][j*width], maxiaml = table[0][j*width], threshold;
    
    //选出block像素中灰度最高和最低值
    for( int i  = 0; i < height; i++ ){
        for( int l = 0; l < width; l++ ){
            if( table[i][j*width + l] < minimal ) minimal = table[i][j*width + l];
            if( table[i][j*width + l] > maxiaml ) maxiaml = table[i][j*width + l];
        }
    }
    //运用大津算法算类间方差，找出给定区域内的全局最佳阈值
    maxMU = Otsu( table, j, minimal + 1, height, width );
    for( k = minimal + 1; k <= maxiaml; k++ ){
        tempMU = Otsu( table, j, k, height, width );
        if( maxMU < tempMU ){
            maxMU = tempMU;
            threshold = k;
        }
    }
    return threshold;
}

double Otsu( BYTE **table, int j, BYTE tempThreshold, DWORD height, DWORD width )
{
    int i, l;
    int Fsum = 0, Bsum = 0;
    double Wf, Wb, MU, Muf, Mub;
    long long N = height * width, Nfgrd = 0, Nbgrd = 0;
    for( i = 0; i < height; i++ ){
        for( l = 0; l < width; l++ ){
            if( table[i][j*width + l] < tempThreshold ){
                Fsum += (int)table[i][j*width + l];
                Nfgrd++;
            }else{
                Bsum += (int)table[i][j*width + l];
                Nbgrd++;
            }
        }
    }
    Wf = (double)( (double)Nfgrd / (double)N );
    Wb = (double)( (double)Nbgrd / (double)N );
    Muf = (double)( (double)Fsum / (double)Nfgrd );
    Mub = (double)( (double)Bsum / (double)Nbgrd );

    return MU = Wf * Wb * pow( Muf - Mub, 2 );
}

void Writeimage( FILE *fp, BITMAPFILEHEADER fileHeader, BITMAPINFOHEADER infoHeader, RGBQUAD Pallete[], BYTE **pixeldata )
{
    WORD bfType = 0x4d42;
    fwrite( &bfType, 2, 1, fp ); //将“BM”写入图片
    fwrite( &fileHeader, sizeof(BITMAPFILEHEADER), 1, fp ); //写入文件头数据
    fwrite( &infoHeader, sizeof(BITMAPINFOHEADER), 1, fp ); //写入信息头数据
    fwrite( Pallete, 4, 256, fp );
    int i, j;
    for( i = 0; i < infoHeader.biHeight; i++ )
        fwrite( pixeldata[i], real_width, 1, fp );
    fclose( fp );
}