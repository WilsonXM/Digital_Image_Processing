/*这里进行的几何变换都是基于真彩图进行的*/
/*命令行中的命令格式为：exe文件 操作类型 操作对象 (可选参数)*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define REAL_WIDTH(i) ( ( i + 31 ) / 32 * 4 )

// --#pragma pack(1)-- //

/*Some pre-definitions of the data types and structure*/
typedef unsigned short WORD;
typedef unsigned int DWORD;
typedef unsigned char BYTE;

/*image file header*/
typedef struct tagBITMAPFILEHEADER{
    //WORD bfType;            这个地方有点问题的，感觉不是14字节。。。。所以单独读取
    DWORD bfSize;
    WORD bfReserved1;
    WORD bfReserved2;
    DWORD bfOffBits;
}BITMAPFILEHEADER;

/*image information header*/
typedef struct tagBITMAPINFOHEADER{
    DWORD biSize;
    DWORD biWidth; //注意：此处的biWidth不是实际的图像宽度，而是理论上每行的像素个数
    DWORD biHeight;
    WORD biPlanes;
    WORD biBitCount;
    DWORD biCompression;
    DWORD biSizeImage;
    DWORD biXPelsPerMeter;
    DWORD biYPelsPerMeter;
    DWORD biClrUsed;
    DWORD biClrImportant;
}BITMAPINFOHEADER;

/* the palette */
typedef struct tagRGBQUAD{
    BYTE rgbBlue;    
    BYTE rgbGreen;   
    BYTE rgbRed;      
    BYTE rgbReserved;
}RGBQUAD;

BYTE **pixeldata = NULL;   
long real_width = 0; //记录每一行实际的字节数

void Readimage(FILE *fp, BITMAPFILEHEADER *fileHeader, BITMAPINFOHEADER *infoHeader, RGBQUAD Pallete[]);
void Writeimage(FILE *fp, BITMAPFILEHEADER fileHeader, BITMAPINFOHEADER infoHeader, RGBQUAD Pallete[], BYTE **pixeldata);
void Meanfiltering(int d, BYTE **mask, BYTE **pixeldataNew, BITMAPINFOHEADER infoHeader);
void Laplacian(int type, int c, BYTE **pixeldataNew, BITMAPINFOHEADER infoHeader);

int main(int argc, char *argv[])
{
    BITMAPFILEHEADER fileHeader;
    BITMAPINFOHEADER infoHeader;
    RGBQUAD pallete[256];
    BYTE **pixeldataNew = NULL;
    BYTE **mask = NULL;
    int d = 0;                      //d是卷积核的边长

    FILE *grayscale;
    FILE *mean;         //均值滤波
    FILE *laplacian;    //拉普拉斯图像增强

    grayscale = fopen(argv[2], "rb");//argv[2]----------------------------------------------------------------------------asdfasdfsdf
    if(grayscale == NULL) {
        printf( "The grayscale image doesn't exist!\n" );
        return -1;
    }
    Readimage(grayscale, &fileHeader, &infoHeader, pallete);
    //构建新的像素点数据空间
    pixeldataNew = (BYTE **)malloc( sizeof(BYTE *) * infoHeader.biHeight );
    for( int i = 0; i < infoHeader.biHeight; i++ ) 
        pixeldataNew[i] = (BYTE *)calloc( real_width, 1 ); //为图像数据分配空间

    if(strcmp(argv[1], "mean") == 0) {  //strcmp(argv[1], "mean") == 0----------------------------------------------------------------------------asdfasdfsdf
        mean = fopen("mean.bmp", "wb");
        if(mean == NULL) {
            printf( "Fail to create the mean filtering of the grayscale image!\n" );
            return -1;
        }
        d = (int)(sqrt(pow(infoHeader.biHeight, 2) + pow(real_width, 2)) * 2.0 / 100.0);
        if(d % 2 == 0) d++;     //把边长弄成奇数方便处理
        //为卷积核分配空间并初始化为全1
        mask = (BYTE **)malloc(sizeof(BYTE *) * d);
        for(int i = 0; i < d; i++) {
            mask[i] = (BYTE *)calloc(sizeof(BYTE), d);
            for(int j = 0; j < d; j++) mask[i][j] = 1;
        }
        Meanfiltering(d, mask, pixeldataNew, infoHeader);
        Writeimage(mean, fileHeader, infoHeader, pallete, pixeldataNew);
        printf( "OK! The mean filtering has been created!\n" );
    } else if(strcmp(argv[1], "laplacian") == 0) {  //strcmp(argv[1], "laplacian") == 0----------------------------------------------------------------------------asdfasdfsdf
        laplacian = fopen("laplacian.bmp", "wb");
        if(laplacian == NULL) {
            printf( "Fail to create the laplacian enhancement of the grayscale image!\n" );
            return -1;
        }
        //选择模式--a表示四领域， b表示八领域；相应地，1表示模式b，0表示模式a
        int type = 1;
        if(strcmp(argv[3], "a") == 0 || strcmp(argv[3], "A") == 0) type = 0;//strcmp(argv[3], "a") == 0 || strcmp(argv[3], "A") == 0-----------------------------asdfasdfsdf
        //设定Laplacian需要加上的细节多少，也就是中心的数的绝对值
        int c = atoi(argv[4]);//atoi(argv[4])----------------------------------------------------------------------------asdfasdfsdf
        Laplacian(type, c, pixeldataNew, infoHeader);
        Writeimage(laplacian, fileHeader, infoHeader, pallete, pixeldataNew);
        printf( "OK! The laplacian enhancement has been created!\n" );
    } else {
        printf("Illeagal operation!\n");
        return -1;
    }

    for( int i = 0; i < infoHeader.biHeight; i++ ) free( pixeldata[i] );
    free( pixeldata );
    for( int i = 0; i < infoHeader.biHeight; i++ ) free( pixeldataNew[i] );
    free( pixeldataNew );

    return 0;
}

void Readimage(FILE *fp, BITMAPFILEHEADER *fileHeader, BITMAPINFOHEADER *infoHeader, RGBQUAD Pallete[])
{
    WORD bfType;
    fseek( fp, 0, SEEK_SET );
    fread( &bfType, sizeof(WORD), 1, fp );/* 单独读取 “BM” */
    if( bfType == 0x4d42 ){
        printf("OK! the image is bmp!\n");
        fread( fileHeader, sizeof(BITMAPFILEHEADER), 1, fp );/*read the image file header*/
        fread( infoHeader, sizeof(BITMAPINFOHEADER), 1, fp );/*read the image information header*/
    }else{
        printf("This is not a bmp image!\n");
        exit(0);
    }
    real_width = REAL_WIDTH( infoHeader->biBitCount * infoHeader->biWidth );
    //读取灰度图的调色板数据，8位的灰度图有256个灰度
    fread( Pallete, sizeof(RGBQUAD), 256, fp );
    //分配存储像素点灰度数据的空间
    pixeldata = (BYTE **)malloc( sizeof(BYTE *) * infoHeader->biHeight );
    for( int i = 0; i < infoHeader->biHeight; i++ ) 
        pixeldata[i] = (BYTE *)calloc( real_width, 1 );
    //从灰度图中读取灰度数据
    for( int i  = 0; i < infoHeader->biHeight; i++ )
        fread( pixeldata[i], real_width, 1, fp );
    fclose( fp );
}

void Writeimage(FILE *fp, BITMAPFILEHEADER fileHeader, BITMAPINFOHEADER infoHeader, RGBQUAD Pallete[], BYTE **pixel)
{
    WORD bfType = 0x4d42;
    fwrite( &bfType, 2, 1, fp ); //将“BM”写入图片
    fwrite( &fileHeader, sizeof(BITMAPFILEHEADER), 1, fp ); //写入文件头数据
    fwrite( &infoHeader, sizeof(BITMAPINFOHEADER), 1, fp ); //写入信息头数据
    fwrite( Pallete, 4, 256, fp );
    int i, j;
    for( i = 0; i < infoHeader.biHeight; i++ )
        fwrite( pixel[i], real_width, 1, fp );
    fclose( fp );
}

void Meanfiltering(int d, BYTE **mask, BYTE **pixeldataNew, BITMAPINFOHEADER infoHeader)
{
    for(int i = 0; i < infoHeader.biHeight; i++) {
        for(int j = 0; j < infoHeader.biWidth; j++) {
            double temp = 0;
            int sum = 0, count = 0;
            for(int k = - (d-1) / 2; k <= (d-1) / 2; k++) 
                for(int p = - (d-1) / 2; p <= (d-1) / 2; p++) 
                    if(i + k >= 0 && i + k < infoHeader.biHeight && j + p >= 0 && j + p < infoHeader.biWidth) {
                        //判断卷积核中的哪些点在图上
                        sum = sum + pixeldata[i + k][j + p];
                        count++;
                    }
            temp = (double)sum / (double)count;
            if(temp > 255) temp = 255;
            else if(temp < 0) temp = 0;
            pixeldataNew[i][j] = (BYTE)temp;
        }
    }
}

void Laplacian(int type, int c, BYTE **pixeldataNew, BITMAPINFOHEADER infoHeader)
{
    if(!type) {     //说明此时进行的是模式a
        //构造拉普拉斯算子图像
        for(int i = 0; i < infoHeader.biHeight; i++) {
            for(int j = 0; j < infoHeader.biWidth; j++) {
                int temp = 0;
                if((i - 1 < 0) || (i + 1 >= infoHeader.biHeight) || (j - 1 < 0) || (j + 1 >= infoHeader.biWidth)) {
                    pixeldataNew[i][j] = pixeldata[i][j];
                    continue;
                } else {
                    temp = (int)pixeldata[i][j - 1] + (int)pixeldata[i][j + 1] + (int)pixeldata[i - 1][j] + (int)pixeldata[i + 1][j] - c * (int)pixeldata[i][j];
                    if(temp > 255) temp = 255;
                    else if(temp < 0) temp = 0;
                    pixeldataNew[i][j] = (BYTE)temp;
                }
            }
        }
    } else {        //说明此时进行模式b
        for(int i = 0; i < infoHeader.biHeight; i++) {
            for(int j = 0; j < infoHeader.biWidth; j++) {
                int temp = 0;
                if((i - 1 < 0) || (i + 1 >= infoHeader.biHeight) || (j - 1 < 0) || (j + 1 >= infoHeader.biWidth)) {
                    pixeldataNew[i][j] = pixeldata[i][j];
                    continue;
                } else {
                    temp = (int)pixeldata[i][j - 1] + (int)pixeldata[i][j + 1] + (int)pixeldata[i - 1][j] + (int)pixeldata[i + 1][j] + (int)pixeldata[i - 1][j - 1] + (int)pixeldata[i - 1][j + 1] + (int)pixeldata[i + 1][j - 1] + (int)pixeldata[i + 1][j + 1] - c * (int)pixeldata[i][j];
                    if(temp > 255) temp = 255;
                    else if(temp < 0) temp = 0;
                    pixeldataNew[i][j] = (BYTE)temp;
                }
            }
        }
    }
    //与原始图像相加
    for(int i = 0; i < infoHeader.biHeight; i++)
        for(int j = 0; j < infoHeader.biWidth; j++)
            pixeldataNew[i][j] = pixeldata[i][j] - pixeldataNew[i][j];
}