#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/*Some pre-definitions of the data types and structure*/
typedef unsigned short WORD;
typedef unsigned int DWORD;
typedef unsigned char BYTE;

/*image file header*/
typedef struct tagBITMAPFILEHEADER{
    //WORD bfType;            这个地方有点问题的，感觉不是14字节。。。。所以单独读取
    DWORD bfSize;
    WORD bfReserved1;
    WORD bfReserved2;
    DWORD bfOffBits;
}BITMAPFILEHEADER;

/*image information header*/
typedef struct tagBITMAPINFOHEADER{
    DWORD biSize;
    DWORD biWidth;
    DWORD biHeight;
    WORD biPlanes;
    WORD biBitCount;
    DWORD biCompression;
    DWORD biSizeImage;
    DWORD biXPelsPerMeter;
    DWORD biYPelsPerMeter;
    DWORD biClrUsed;
    DWORD biClrImportant;
}BITMAPINFOHEADER;

/* t h e   p a l e t t e */
typedef struct tagRGBQUAD{
    BYTE rgbBlue;    
    BYTE rgbGreen;   
    BYTE rgbRed;      
    BYTE rgbReserved;
}RGBQUAD;

typedef struct tagYUVQUAD{
    BYTE y;
    char u;
    char v;
}YUVQUAD;

int main()
{
    WORD bfType;
    BITMAPFILEHEADER fileHeader;
    BITMAPINFOHEADER infoHeader;
    RGBQUAD palette;
    YUVQUAD yuv;

    FILE *fp;/*point to the initial bmp*/
    FILE *grayscale, *colorful;/*point to the grayscale file and the colorful image after changing*/

    long width;/*the real width of every line*/
    long offset;/*the bytes of lines must be multiplied by 4*/
    fp = fopen( "24.bmp", "rb" );
    grayscale = fopen( "grayscale.bmp", "wb" );
    colorful = fopen( "newcolor.bmp", "wb" );
    
    if( fp == NULL ){
        printf("Open Error!\n");
        return 0;
    }

    fseek( fp, 0, SEEK_SET );
    fread( &bfType, sizeof(WORD), 1, fp );/* 单独读取 “BM” */
    if( bfType == 0x4d42 ){
        printf("OK, the image is bmp!\n");
        fread( &fileHeader, sizeof(BITMAPFILEHEADER), 1, fp );/*read the image file header*/
        fread( &infoHeader, sizeof(BITMAPINFOHEADER), 1, fp );/*read the image information header*/
    }else{
        printf("This is not a bmp image!\n");
    }
    width = ( infoHeader.biWidth * infoHeader.biBitCount + 31 ) / 32 * 4;
    offset = width - ( infoHeader.biWidth * infoHeader.biBitCount + 7 ) / 8;

    if( infoHeader.biBitCount == 24 ){
        int i, j;
        //write in the grayscle image
        fwrite( &bfType, sizeof(WORD), 1, grayscale );
        fwrite( &fileHeader, sizeof(BITMAPFILEHEADER), 1, grayscale );
        fwrite( &infoHeader, sizeof(BITMAPINFOHEADER), 1, grayscale );

        //write in the colorful image
        fwrite( &bfType, sizeof(WORD), 1, colorful );
        fwrite( &fileHeader, sizeof(BITMAPFILEHEADER), 1, colorful );
        fwrite( &infoHeader, sizeof(BITMAPINFOHEADER), 1, colorful );

        for( i = 0; i < infoHeader.biHeight; i++ ){
            for( j = 0; j < infoHeader.biWidth; j++ ){
                int temp[3], tempyuv[3]; /*temp[]储存转换为int的rgb结果, tempyuv[]储存int的yuv结果*/
                char string[16];
                fread( &palette.rgbBlue, 1, 1, fp );
                fread( &palette.rgbGreen, 1, 1, fp );
                fread( &palette.rgbRed, 1, 1, fp );
                palette.rgbReserved = 0;
                temp[0] = palette.rgbRed;
                temp[1] = palette.rgbGreen;
                temp[2] = palette.rgbBlue;

                /* R G B --> Y U V and write a grayscale bmp */
                tempyuv[0] = ( 299*temp[0] + 587*temp[1] + 114*temp[2] ) / 1000;   //Y
                tempyuv[1] = ( -147*temp[0] - 289*temp[1] + 435*temp[2] ) / 1000;  //U
                tempyuv[2] = ( 615*temp[0] - 515*temp[1] - 100*temp[2] ) / 1000;   //V
                
                /*rearrange the gray intensity to lie between [0, 255]*/
                int k;
                for( k = 0; k < 3; k++ ){
                    if(tempyuv[0] < 0) temp[0] = 0;
                    else if(tempyuv[0] > 255) temp[0] = 255;
                }
                
                yuv.y = tempyuv[0];
                yuv.u = tempyuv[1];
                yuv.v = tempyuv[2];
                fwrite( &yuv.y, 1, 1, grayscale );
                fwrite( &yuv.y, 1, 1, grayscale );
                fwrite( &yuv.y, 1, 1, grayscale );

                /*change the luminance value Y and then rearrange it*/
                for( k = 0; k < 3; k++ ){
                    tempyuv[0] += 5;
                    if(tempyuv[0] < 0) tempyuv[0] = 0;
                    else if(tempyuv[0] > 255) tempyuv[0] = 255;
                }

                /* Y U V --> R G B and write a colorful bmp */
                temp[0] = ( 1000*tempyuv[0] + 1140*tempyuv[2] ) / 1000;   //R
                temp[1] = ( 1000*tempyuv[0] - 395*tempyuv[1] - 581*tempyuv[2] ) / 1000;    //G
                temp[2] = ( 1002*tempyuv[0] + 2036*tempyuv[1]) / 1000;  //B
                palette.rgbRed = temp[0];
                palette.rgbGreen = temp[1];
                palette.rgbBlue = temp[2];
                fwrite( &palette.rgbBlue, 1, 1, colorful );
                fwrite( &palette.rgbGreen, 1, 1, colorful );
                fwrite( &palette.rgbRed, 1, 1, colorful );
            }
            if( offset && j != infoHeader.biWidth-1 ){
                fseek( fp, offset, SEEK_CUR );
            }
        }
        fclose(grayscale);
        fclose(colorful);
    }else{
        printf("This is not a true color image!\n");
    }
    system("pause");
    return 0;
}
